package ru.dk.MEP;

public class Matrix
{
	public static int w,h;
	private static Cell[][] ArrayOfCells;
	public static double accuracy;
	public static void Init(int w_, int h_)
	{
		accuracy=3;
		w=(int) Math.round(w_/accuracy);
		h=(int) Math.round(h_/accuracy);
		ArrayOfCells= new Cell[w][h];
		for(int i=0;i<w;i++)
			for(int j=0;j<h;j++)
				ArrayOfCells[i][j]=new Cell(/*i,j*/);
		Particle.particles= new Particle[(w*h)];
		for(int i=0;i<Particle.particles.length;i++)
				Particle.particles[i]=null;
	}
	
	public static void Update()
	{
		for(int i=0;i<w;i++)
			for(int j=0;j<h;j++)
				ArrayOfCells[i][j].is_needed=false;
		
		for(int i=0;i<=Particle.n_max;i++)
			if(Particle.particles[i]!=null)
				ArrayOfCells[Particle.particles[i].x][Particle.particles[i].y].is_needed=true;
	}
}
