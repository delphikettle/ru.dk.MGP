package ru.dk.MEP;

public class Cell
{
	boolean is_needed;//
	//static int x,y;//coordinates
	int fx,fy;//force on x and y
	public Cell(/*int x_, int y_*/)
	{
		//this.x=x_;
		//this.y=y_;
		this.is_needed=false;
		this.fx=0;
		this.fy=0;
	}
}
